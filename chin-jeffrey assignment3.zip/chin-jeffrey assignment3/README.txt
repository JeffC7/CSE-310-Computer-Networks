This program displays information for the first ARP packet exchange in a pcap file.

The only external library used was dpkt.

To run the program, run the command "py analysis_pcap_arp.py". You will then be prompted in the console to type the name of the pcap file which should be in the same directory.  